<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'global' );

/** Database username */
define( 'DB_USER', 'user' );

/** Database password */
define( 'DB_PASSWORD', 'passwordhere' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         ')g B6<*(6yc!-;;sTvXpjDi~rhf,{UG+S7Pmr^|_mn6(XV(; QeH7=[$>F_cwTI#' );
define( 'SECURE_AUTH_KEY',  '~|e5t3n!$t^jP^&)%Ncmeb@yJ~Kk1BrM) #/s%1&@Y~K(o7M}^P&*:vs/E^,BE(2' );
define( 'LOGGED_IN_KEY',    '74$s@ I^n(o# RA*OqHe8X1v]]xtf^m^cEDzL# D:|x#1X7, +OvYPW:inIBPu|C' );
define( 'NONCE_KEY',        'j%>jF,0bw$qJ8#4C/J0*9tj^5SbOTp#sOT4@8+Mn,`Oq 6XK:[vU&`waQnUKJ?Fb' );
define( 'AUTH_SALT',        'KS5Os,eI[`kxareh`^Xz;JLAF%^m&ez`n9;<x6J*i Y]=u/QTKm`G&&@7nR-7r+M' );
define( 'SECURE_AUTH_SALT', '^]!o~EOL!=c_|2^CdVXV4*nsBy^j ufJiijw*K>iO|lza92*r7/xr2_~kI5[MAH{' );
define( 'LOGGED_IN_SALT',   '`(g)ZPMKWq#F%PxRlUfs&&$v%&PDYy[ZtB(0<c wQFc,oj~^xpQCiN> R]&`FiS}' );
define( 'NONCE_SALT',       ',wioQTU3$T7*a7?j Yd<x!<}6]_)x*Qsjd(W_Hiq+|Ek=:o(Q&HXKOCYQ}hbbPWc' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'stryber_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
